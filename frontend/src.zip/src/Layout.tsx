// Layout.tsx
import React, { useState } from "react";
import Navbar from "./Components/Navbar/Navbar";
import Sidebar from "./Components/Siderbar/Sidebar";
import { Outlet } from "react-router-dom";
import { FaBars, FaTimes } from "react-icons/fa";

const Layout: React.FC = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const alarmLinks = [
    { to: "Real-alarm", label: "Real Alarm Table" },
    { to: "Create Real-alarm", label: "Create Real Alarm" },
    { to: "Update Real-alarm", label: "Update Real Alarm" },
    { to: "Delete Real-alarm", label: "Delete Real Alarm" },
  ];

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  return (
    <>
      {/* 顶部导航栏 */}
      <Navbar />

      {/* Hamburger Menu 汉堡菜单按钮，仅在小屏幕上显示 */}
      <div className="md:hidden fixed top-0 left-0 p-4 z-50">
        <button onClick={toggleSidebar} className="text-black">
          {isSidebarOpen ? <FaTimes size={24} /> : <FaBars size={24} />}
        </button>
      </div>

      {/* Sidebar for large screens 侧边栏（大屏幕显示）*/}
      <Sidebar links={alarmLinks} title="Alarm Dashboard" />

      {/* Sidebar overlay for small screens 侧边栏覆盖层（小屏幕显示）*/}
      {isSidebarOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-40 md:hidden" onClick={toggleSidebar}>
          <Sidebar links={alarmLinks} title="Alarm Dashboard" />
        </div>
      )}

      {/* Main 内容区域 */}
      <div className="flex pt-20"> {/* pt-20 根据 Navbar 的高度调整 */}
        <main className={`flex-1 ${isSidebarOpen ? "ml-0" : "ml-64"} p-4`}>
          <Outlet /> {/* 渲染嵌套路由的内容 */}
        </main>
      </div>
    </>
  );
};

export default Layout;
