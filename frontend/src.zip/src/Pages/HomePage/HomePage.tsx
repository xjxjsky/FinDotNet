import React from 'react'
import Hero from '../../Components/Hero/Hero'

interface Props {}

const HomePage = (props: Props) => {
  return (
    <div>
        <Hero />
    </div>
  )
}

export default HomePage