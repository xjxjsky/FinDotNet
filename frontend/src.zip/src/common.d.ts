export interface AlarmProfile {
    
  }